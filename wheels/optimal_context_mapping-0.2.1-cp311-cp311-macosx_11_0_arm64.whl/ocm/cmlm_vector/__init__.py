__version__ = '0.2.0'
from .memory import Memory
__all__ = ['Memory', '__version__']
